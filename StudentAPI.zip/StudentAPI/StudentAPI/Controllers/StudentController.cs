﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using StudentAPI.Models;
using StudentAPI.Services;

namespace StudentAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize] //Protected APIs
    public class StudentController : ControllerBase
    {
        private readonly StudentService _service;

        public StudentController(StudentService service)
        {
            _service = service;
        }

        //GET ALL
        [HttpGet]
        public IActionResult Get()
        {
            var students = _service.GetAll();
            return Ok(students);
        }

        //GET BY ID
        [HttpGet("{id}")]
        public IActionResult Get(int id)
        {
            var student = _service.GetById(id);

            if (student == null)
                return NotFound("Student not found");

            return Ok(student);
        }

        //CREATE
        [HttpPost]
        public IActionResult Post([FromBody] Student student)
        {
            if (student == null)
                return BadRequest("Invalid data");

            var createdStudent = _service.Add(student);

            return Ok(createdStudent);
        }

        //UPDATE
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] Student student)
        {
            if (student == null)
                return BadRequest("Invalid data");

            var existing = _service.GetById(id);
            if (existing == null)
                return NotFound("Student not found");

            student.Id = id;

            var updated = _service.Update(student);

            return Ok(updated);
        }

        //DELETE
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var existing = _service.GetById(id);

            if (existing == null)
                return NotFound("Student not found");

            _service.Delete(id);

            return Ok("Deleted successfully");
        }
    }
}