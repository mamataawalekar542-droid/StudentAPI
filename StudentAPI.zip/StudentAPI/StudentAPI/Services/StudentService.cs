﻿using StudentAPI.Models;
using StudentAPI.Repositories;

namespace StudentAPI.Services
{
    public class StudentService
    {
        private readonly IStudentRepository _repo;

        public StudentService(IStudentRepository repo)
        {
            _repo = repo;
        }

        public List<Student> GetAll() => _repo.GetAll();
        public Student GetById(int id) => _repo.GetById(id);
        public Student Add(Student student) => _repo.Add(student);
        public Student Update(Student student) => _repo.Update(student);
        public void Delete(int id) => _repo.Delete(id);
    }
}