﻿using System.Collections.Generic;
using StudentAPI.Models;

namespace StudentAPI.Repositories
{
    public interface IStudentRepository
    {
        List<Student> GetAll();
        Student GetById(int id);
        Student Add(Student student);
        Student Update(Student student);
        void Delete(int id);
    }
}