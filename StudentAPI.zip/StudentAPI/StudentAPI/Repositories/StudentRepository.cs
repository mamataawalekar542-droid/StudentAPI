﻿using System.Collections.Generic;
using System.Linq;
using StudentAPI.Models;
using StudentAPI.Data;

namespace StudentAPI.Repositories
{
    public class StudentRepository : IStudentRepository
    {
        private readonly AppDbContext _context;

        // Constructor
        public StudentRepository(AppDbContext context)
        {
            _context = context;
        }

        // GET ALL
        public List<Student> GetAll()
        {
            return _context.Students.ToList();
        }

        // GET BY ID
        public Student GetById(int id)
        {
            return _context.Students.FirstOrDefault(s => s.Id == id);
        }

        // ADD
        public Student Add(Student student)
        {
            _context.Students.Add(student);
            _context.SaveChanges();
            return student;
        }

        // UPDATE
        public Student Update(Student student)
        {
            var existingStudent = _context.Students.FirstOrDefault(s => s.Id == student.Id);

            if (existingStudent == null)
            {
                return null;
            }

            existingStudent.Name = student.Name;
            existingStudent.Email = student.Email;
            existingStudent.Age = student.Age;
            existingStudent.Course = student.Course;

            _context.SaveChanges();

            return existingStudent;
        }

        // DELETE
        public void Delete(int id)
        {
            var student = _context.Students.FirstOrDefault(s => s.Id == id);

            if (student != null)
            {
                _context.Students.Remove(student);
                _context.SaveChanges();
            }
        }
    }
}